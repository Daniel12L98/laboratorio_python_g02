lista = []
for i in range(1, 101):
    lista.append(i)
print("La lista es: {}".format(lista))
print("Los valores comprendidos entra la posición 10 y 35 son: {}".format(lista[9:35]))
