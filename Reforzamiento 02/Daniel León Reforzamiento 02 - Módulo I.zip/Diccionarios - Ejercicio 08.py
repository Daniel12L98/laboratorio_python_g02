var_1 = {"nombre": "Pedro", "edad": 23, "salario": 3500}
var_1["carrera"] = "ingenieria"
print("El diccionario es: {}".format(var_1))
