# Lista de cursos de la universidad

cursos_1 = ["Análisis químico", "Ingeniería de la corrosión", "Cálculo económico", "Matemática básica", "Balance materia", "Introducción a la IQ"]

print("La lista con los cursos de la universidad son: {}".format(cursos_1))
