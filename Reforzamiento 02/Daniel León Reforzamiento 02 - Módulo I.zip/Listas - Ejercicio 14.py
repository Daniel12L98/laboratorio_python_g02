lista_1 = [32.6, True, False, 96.4, 9.6, False, 81.4, True]
indice_1 = 1
indice_2 = 5
del lista_1[indice_1]
del lista_1[indice_2]
print(lista_1)

