# Lista incluyendo floats y booleanos

lista_1 = [32.6, True, False, 96.4, 9.6, False, 81.4, True]

lista_1.clear()

print("La lista actualizada es:", lista_1)
