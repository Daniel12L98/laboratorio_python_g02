# Lista incluyendo floats y booleanos

lista_1 = [32.6, True, False, 96.4, 9.6, False, 81.4, True]

dato_1 = lista_1[0]
dato_2 = lista_1[1]
dato_3 = lista_1[2]
dato_4 = lista_1[3]
dato_5 = lista_1[4]
dato_6 = lista_1[5]
dato_7 = lista_1[6]
dato_8 = lista_1[7]

print("Los tipos de cada dato de la lista_1 son:",type(dato_1), type(dato_2), type(dato_3), type(dato_4), type(dato_5), type(dato_6), type(dato_7), type(dato_8))


