lista = []
for i in range(1, 101):
    lista.append(i)
print("La lista es: {}".format(lista))
