# Lista de cursos de la universidad

cursos_1 = ["Análisis químico", "Ingeniería de la corrosión", "Cálculo económico", "Matemática básica", "Balance materia", "Introducción a la IQ"]

cursos_1.reverse()

print("La lista con los cursos invertida de la universidad es: {}".format(cursos_1))