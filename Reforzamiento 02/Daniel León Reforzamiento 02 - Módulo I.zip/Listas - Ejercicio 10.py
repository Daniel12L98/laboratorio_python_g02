# Lista nueva

lista_1 = [50, 80, 15, 6, 90, 46, 100]

lista_1.sort()

print("La lista ordenada es: {}".format(lista_1))
