var_1 = {"nombre": "Pedro", "edad": 23, "salario": 3500}
var_2 = list(var_1)
print("El tipo de dato de la lista es: {}".format(type(var_2)))
