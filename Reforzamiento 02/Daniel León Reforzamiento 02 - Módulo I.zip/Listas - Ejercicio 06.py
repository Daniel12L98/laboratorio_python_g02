# Lista de cursos

cursos_1 = ["Análisis químico", "Ingeniería de la corrosión", "Cálculo económico", "Matemática básica", "Balance materia", "Introducción a la IQ"]

cursos_1.append("Análisis químico")
cursos_1.append("Análisis químico")
cursos_1.append("Matemática básica")
cursos_1.append("Matemática básica")
cursos_1.append("Matemática básica")

# Lista de cursos actualizada con repetición

print("Mi lista actualizada con repeción es: {}".format(cursos_1))

print("La cantidad de veces que se repite 'Análisis químico' es: {}".format(cursos_1.count("Análisis químico")))
print("La cantidad de veces que se repite 'Matemática básica' es: {}".format(cursos_1.count("Matemática básica")))

