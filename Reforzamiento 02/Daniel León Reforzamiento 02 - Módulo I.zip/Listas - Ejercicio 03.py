# Lista actualizada con 6 nuevos objetos

cursos_1 = ["Análisis químico", "Ingeniería de la corrosión", "Cálculo económico", "Matemática básica",
            "Balance materia", "Introducción a la IQ", "Reloj", "Cartuchera", "Celular", "Billetera", "Mochila",
            "Lapiceros"]

# Se quitarán 2 elementos de la nueva lista

cursos_1.remove("Ingeniería de la corrosión")
cursos_1.remove("Billetera")

print("La lista actualizada es: {}".format(cursos_1))
