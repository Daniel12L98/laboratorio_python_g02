departamento = {"departamento_1": "tumbes", "departamento_2": "piura", "departamento_3": "junin", "departamento_4": "tacna", "departamento_5": "cusco", "departamento_6": "ica"}
print("Departamentos antes de eliminar: {}".format(departamento))
del departamento["departamento_1"]
print("Los departamentos actualizados son: {}".format(departamento))
