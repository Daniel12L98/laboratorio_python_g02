# Lista de cursos

cursos_1 = ["Análisis químico", "Ingeniería de la corrosión", "Cálculo económico", "Matemática básica", "Balance materia", "Introducción a la IQ"]

cursos_1.pop(0)

print("La lista de cursos borrando el primer item es: {}".format(cursos_1))
