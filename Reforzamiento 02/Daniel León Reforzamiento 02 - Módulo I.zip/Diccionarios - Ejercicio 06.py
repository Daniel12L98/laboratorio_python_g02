var_1 = {"nombre": "Pedro", "edad": 23, "salario": 3500}
diccionario_nuevo = dict([("edad", 23)])
print(diccionario_nuevo)