var_1 = {"nombre": "Pedro", "edad": 23, "salario": 3500}
print("El diccionario tiene el siguiente contenido: {}".format(var_1))
