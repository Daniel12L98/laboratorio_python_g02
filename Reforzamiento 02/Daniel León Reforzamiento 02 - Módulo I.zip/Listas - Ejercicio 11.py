# Lista incluyendo floats y booleanos

lista_1 = [32.6, True, False, 96.4, 9.6, False, 81.4, True]

print("El penultimo valor es: {}".format(lista_1[-2]))
print("El último valor es: {}".format(lista_1[-1]))
