# Lista vacia

lista = []

lista.append(36.5)
lista.append(51)
lista.append("Daniel")
lista.append(95.6)
lista.append(45)
lista.append("Ingeniería")
lista.append(79.7)
lista.append(78)
lista.append("UNMSM")

print("La lista actualizada es: {}".format(lista))
