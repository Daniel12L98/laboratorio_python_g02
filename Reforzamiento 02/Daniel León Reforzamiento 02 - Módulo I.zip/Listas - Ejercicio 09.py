# Lista de cursos de la universidad

cursos_1 = ["Análisis químico", "Ingeniería de la corrosión", "Cálculo económico", "Matemática básica", "Balance materia", "Introducción a la IQ"]

# Lista de datos

lista = [36.5, 51, 'Daniel', 95.6, 45, 'Ingeniería', 79.7, 78, 'UNMSM']

# Suma de ambas listas

suma_listas = cursos_1 + lista

print("La suma de las listas es: {}".format(suma_listas))
