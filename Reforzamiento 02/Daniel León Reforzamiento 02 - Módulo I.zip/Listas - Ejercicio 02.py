# Lista de cursos de la universidad

cursos_1 = ["Análisis químico", "Ingeniería de la corrosión", "Cálculo económico", "Matemática básica", "Balance materia", "Introducción a la IQ"]

# Se agregarán 6 objetos nuevos

cursos_1.append("Reloj")
cursos_1.append("Cartuchera")
cursos_1.append("Celular")
cursos_1.append("Billetera")
cursos_1.append("Mochila")
cursos_1.append("Lapiceros")

print("La lista actualizada es: {}".format(cursos_1))
