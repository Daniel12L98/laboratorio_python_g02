lista = []
for i in range(1, 11):
    lista.append(i * i)
print("La lista es: {}".format(lista))
