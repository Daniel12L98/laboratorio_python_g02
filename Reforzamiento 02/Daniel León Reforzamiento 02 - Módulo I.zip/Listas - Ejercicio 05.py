# Lista de cursos de la universidad creada

cursos_1 = ["Análisis químico", "Ingeniería de la corrosión", "Cálculo económico", "Matemática básica", "Balance materia", "Introducción a la IQ"]

print("La cantidad total de items en mi lista es: {}".format(len(cursos_1)))
