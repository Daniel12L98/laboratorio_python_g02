var_1 = {"nombre": "Pedro", "edad": 23, "salario": 3500}
var_1["dni"] = 13648592
print("El valor del salario es:", var_1["salario"])
