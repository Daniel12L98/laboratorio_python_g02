var1 = {"Nombre": "Daniel", "Carrera": "Ingeniería", "Edad": 25, "Año de nacimiento": 1998}
print("El valor de var1 es:", format(var1))
print("El Nombre es:", var1["Nombre"])
print("La carrera es:", var1["Carrera"])
print("La edad es:", var1["Edad"])
print("El año de nacimiento es:", var1["Año de nacimiento"])
