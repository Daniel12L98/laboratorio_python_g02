nombre = "Daniel"
mi_saludo = "¡Hola {}!".format(nombre)

print(mi_saludo)
