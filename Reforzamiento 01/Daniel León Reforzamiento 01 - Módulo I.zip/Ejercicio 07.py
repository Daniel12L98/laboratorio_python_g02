var1 = 14
var2 = 42
var3 = 85
Resultado = var1 % 3 + var2 % 5 + var3 % 7
print("El resultado de la suma es:", Resultado)
