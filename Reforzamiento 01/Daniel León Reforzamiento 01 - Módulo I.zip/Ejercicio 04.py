var1 = 5 #var1 es el radio de la esfera
import math
volumen = (4 / 3) * math.pi * var1 ** 3
print("El volumen de la esfera es:",  volumen)
