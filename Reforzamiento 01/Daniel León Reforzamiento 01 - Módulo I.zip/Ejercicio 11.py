var1 = 2
Resultado = pow(var1, 5) / 10
print("El resultado es del tipo:", type(Resultado))
print("El resultado es:", Resultado)
