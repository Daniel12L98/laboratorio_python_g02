var1 = 10 # var1 es tipo int y su valor es 10

Resultado_1 = var1 * 10

Resultado_2 = Resultado_1 - 10

print("El resultado es:", Resultado_2)
