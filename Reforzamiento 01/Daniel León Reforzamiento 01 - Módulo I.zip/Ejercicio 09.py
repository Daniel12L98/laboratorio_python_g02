var1 = 5
exponente = pow(var1, 4)  # Variable elevado al exponente 4
multiplicacion = exponente * 2  # Producto del resultado del exponente multiplicado por 2
Resultado = exponente - multiplicacion  # Diferencia de los resultados de exponente y multiplicación
print("El resultado es:", Resultado)
