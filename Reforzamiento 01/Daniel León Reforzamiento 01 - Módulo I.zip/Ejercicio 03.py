var1 = "100"
var2 = 50
var3 = int(var1)
print("El valor de la suma es:", var2 + var3)
