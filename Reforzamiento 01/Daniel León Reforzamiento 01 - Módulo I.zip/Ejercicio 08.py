lista_vacia = []
lista_no_vacia = [1, 2]
if not lista_vacia:
    print("La lista vacía si está vacía")
else:
    print("La lista vacía no está vacía")
if not lista_no_vacia:
    print("La lista que tiene elementos está vacía")
else:
    print("La lista que tiene elementos no está vacía")
