var1 = 3.3
var2 = 4.6
var3 = 1.8
var4 = 9.9
var5 = 7.1
suma = var1 + var2 + var3 + var4 + var5
media = suma/5
print("El valor de la media es:", media)
